﻿public class Question2
{
    public string QuestionText { get; set; }       // Holds the question text
    public string[] Options { get; set; }          // Holds the answer options
    public int CorrectAnswerIndex { get; set; }    // Holds the index of the correct answer
}
